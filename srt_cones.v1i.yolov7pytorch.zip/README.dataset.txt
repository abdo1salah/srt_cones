# srt_cones > 2024-11-30 6:06pm
https://universe.roboflow.com/abdelrahman-salah/srt_cones

Provided by a Roboflow user
License: CC BY 4.0

